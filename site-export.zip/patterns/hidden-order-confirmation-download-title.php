<?php
/**
 * Title: Order confirmation downloads title
 * Slug: assembler/hidden-order-confirmation-downloads-title
 * Inserter: no
 */
declare( strict_types = 1 );
?>

<!-- wp:heading {"fontSize":"medium"} -->
	<h2 class="wp-block-heading has-medium-font-size"><?php esc_html_e('Downloads', 'assembler');?></h2>
<!-- /wp:heading -->
