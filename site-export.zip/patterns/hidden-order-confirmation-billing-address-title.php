<?php
/**
 * Title: Order confirmation billing address title
 * Slug: assembler/hidden-order-confirmation-billing-address-title
 * Inserter: no
 */
declare( strict_types = 1 );
?>

<!-- wp:heading {"fontSize":"medium"} -->
	<h2 class="wp-block-heading has-medium-font-size"><?php esc_html_e('Billing address', 'assembler');?></h2>
<!-- /wp:heading -->
