<?php
/**
 * Title: Order confirmation additional information title
 * Slug: assembler/hidden-order-confirmation-additional-information-title
 * Inserter: no
 */
declare( strict_types = 1 );
?>

<!-- wp:heading {"fontSize":"medium"} -->
	<h2 class="wp-block-heading has-medium-font-size"><?php esc_html_e('Additional information', 'assembler');?></h2>
<!-- /wp:heading -->
